# 🤖 AI Resume Screener
### n8n + Claude API + Google Drive + Notion

Sistem screening CV otomatis berbasis AI. Upload PDF CV ke Google Drive → Claude ekstrak data & scoring → hasil masuk Notion database dalam < 10 detik.

---

## 🎯 Problem
HR butuh 5–10 menit per CV untuk screening awal. Dengan 100 pelamar, itu 8+ jam kerja manual yang membosankan dan rawan bias.

## 💡 Solution
Upload PDF CV ke Google Drive → n8n trigger otomatis → Claude baca & ekstrak 15+ fields → scoring terbobot → Notion database terisi otomatis → Slack alert untuk top candidates.

---

## ⚡ Features
- ✅ Baca PDF CV apapun tanpa template khusus
- ✅ Ekstrak 15+ field data kandidat otomatis
- ✅ Weighted scoring: Skill 40% + Experience 35% + Education 15% + Language 10%
- ✅ Auto-tier: Top Candidate / Consider / Maybe / Not Fit
- ✅ Red flags detection (gap, inkonsistensi)
- ✅ Slack alert untuk kandidat score >= 70
- ✅ Processing time: < 10 detik per CV

---

## 🏗️ Architecture
```
PDF Upload → Google Drive
                 ↓ (trigger n8n)
           Download File
                 ↓
           Convert Base64
                 ↓
           Claude API (baca PDF + ekstrak JSON)
                 ↓
           Parse + Hitung Score
                 ↓
           Notion Database ← create page
                 ↓
           IF score >= 70?
           ↓           ↓
      Slack Alert   (skip)
```

---

## 🛠️ Tech Stack
| Tool | Fungsi |
|------|--------|
| n8n | Workflow engine + loop |
| Claude API | CV reading + data extraction |
| Google Drive API | File trigger + storage |
| Notion API | Candidate database |
| Slack | Top candidate alerts |

---

## 📊 Impact (100 CV)
| Metric | Manual | AI System |
|--------|--------|-----------|
| Time per CV | 5-10 menit | < 10 detik |
| Total time | 8+ jam | ~17 menit |
| Consistency | Variable | 100% |
| Bias risk | Tinggi | Minimal |

---

## 🚀 Quick Start

### Prerequisites
- n8n instance
- Anthropic API key
- Google Drive + Google Cloud credentials
- Notion API key + database

### Setup
1. Clone repo & import `workflow.json` ke n8n
2. Copy `.env.example` → `.env`, isi semua credentials
3. Buat Notion database dari `notion-schema.json`
4. Buat folder **"CV Incoming"** di Google Drive
5. Setup Google Drive trigger di n8n
6. Kustomisasi prompt di `prompts/extraction-prompt.md` sesuai posisi yang dibuka
7. Drop PDF CV ke folder → cek Notion

---

## 📁 Struktur File
```
ai-resume-screener/
├── README.md
├── workflow.json
├── notion-schema.json
├── .env.example
├── setup-guide.md
├── prompts/
│   └── extraction-prompt.md
├── sample-cv/
│   └── sample-anonymized.pdf
└── screenshots/
    ├── workflow-n8n.png
    ├── notion-database.png
    └── slack-alert.png
```

---

## 🔧 Environment Variables
```env
ANTHROPIC_API_KEY=sk-ant-xxxxx
NOTION_API_KEY=secret_xxxxx
NOTION_DB_ID=your-database-id
GOOGLE_DRIVE_FOLDER_ID=your-folder-id
SLACK_WEBHOOK_URL=https://hooks.slack.com/services/xxx
TOP_CANDIDATE_THRESHOLD=70
```

---

## 🤝 Author
Built as part of AI Automation Engineer portfolio.

**Tech Stack:** n8n · Claude API · Google Drive · Notion · Slack
