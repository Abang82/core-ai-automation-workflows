# Claude Extraction Prompt — AI Resume Screener

Gunakan prompt ini sebagai `content[1].text` saat mengirim PDF ke Claude API.

## Prompt

```
INSTRUKSI:
Kamu adalah AI recruiter yang menganalisis CV dengan objektif.
Baca dokumen CV yang diberikan dan ekstrak semua informasi penting.

OUTPUT FORMAT:
Balas HANYA dengan JSON murni. Tidak ada teks lain. Tidak ada markdown.
Tidak ada penjelasan. Hanya JSON valid.

JSON SCHEMA:
{
  "full_name": "string",
  "email": "string",
  "phone": "string",
  "location": "string",
  "target_position": "string | null",
  "years_experience": number,
  "education": "string",
  "top_skills": ["skill1", "skill2", "skill3"],
  "languages": ["Indonesian", "English"],

  "skill_match": number,
  "experience_score": number,
  "education_score": number,
  "language_score": number,

  "summary": "string",
  "red_flags": ["string"],
  "highlights": ["string"]
}

JOB REQUIREMENTS (untuk scoring):
- Posisi: [ISI POSISI YANG DIBUKA]
- Skill wajib: [ISI SKILL UTAMA]
- Pengalaman min: [ISI TAHUN] tahun
- Pendidikan min: [ISI JENJANG]
- Bahasa: Bahasa Indonesia (wajib), Inggris (nilai plus)

ATURAN SCORING (0-100):
- Jujur dan objektif
- Jika info tidak ada di CV, anggap 0
- red_flags boleh kosong [] jika tidak ada masalah
```

## Cara Kustomisasi
Ganti bagian JOB REQUIREMENTS setiap kali membuka posisi baru.
