# 🤖 Multi-Agent Research Assistant
### n8n + Claude API + Web Search + Notion

Pipeline riset otomatis dengan 4 AI agent yang bekerja berurutan. Input topik → laporan profesional siap dalam ~5 menit.

---

## 🎯 Problem
Research manual butuh waktu berhari-hari: cari data, analisis, tulis laporan. Hasilnya seringkali tidak konsisten dan sulit di-scale.

## 💡 Solution
4 AI agents bekerja secara berurutan dalam pipeline otomatis:
- **Planner Agent** → pecah topik jadi research questions
- **Search Agent** → cari data real-time dari internet (loop)
- **Analyst Agent** → sintesis semua findings jadi insights
- **Writer Agent** → tulis laporan profesional → push ke Notion

---

## ⚡ Features
- ✅ Fully autonomous — zero human intervention setelah trigger
- ✅ Real-time web search via Claude Web Search Tool
- ✅ Structured multi-agent pipeline (Planner → Search → Analyst → Writer)
- ✅ Output langsung ke Notion database
- ✅ Slack notification saat laporan selesai
- ✅ Processing time: ~5 menit untuk riset komprehensif

---

## 🏗️ Architecture
```
Input Webhook (topic, scope, depth)
        ↓
[AGENT 1] Planner     → 5-8 research questions (JSON)
        ↓
[AGENT 2] Search      → loop per question + web search
        ↓
        Merge all findings
        ↓
[AGENT 3] Analyst     → cross-reference → key insights (JSON)
        ↓
[AGENT 4] Writer      → professional report (Markdown)
        ↓
Notion Page + Slack Alert
```

---

## 🛠️ Tech Stack
| Tool | Fungsi |
|------|--------|
| n8n | Orchestration + loop management |
| Claude Sonnet | Semua 4 AI agents |
| Web Search Tool | Real-time data untuk Search Agent |
| Notion API | Structured report storage |
| Slack | Completion notifications |

---

## 📊 Performance
| Metric | Manual | AI System |
|--------|--------|-----------|
| Time per report | 2-3 hari | ~5 menit |
| Questions covered | ~5 (biased) | 7-8 (systematic) |
| Sources checked | 10-20 | 50-100+ |
| Consistency | Variable | Reproducible |

---

## 🚀 Quick Start

### Prerequisites
- n8n instance
- Anthropic API key (dengan Web Search access)
- Notion API key + database
- Slack webhook

### Setup
1. Import `workflow.json` ke n8n
2. Setup credentials: Anthropic, Notion, Slack
3. Buat Notion database dari `notion-schema.json`
4. Test dengan POST ke webhook URL:
```json
{
  "topic": "Perkembangan AI di Southeast Asia 2025",
  "scope": "market",
  "depth": "comprehensive",
  "output_lang": "id"
}
```
5. Tunggu ~5 menit → laporan muncul di Notion

---

## 📁 Struktur File
```
multi-agent-research-n8n/
├── README.md
├── workflow.json
├── notion-schema.json
├── .env.example
├── setup-guide.md
├── prompts/
│   ├── 01-planner.md
│   ├── 02-search-agent.md
│   ├── 03-analyst.md
│   └── 04-writer.md
├── examples/
│   ├── sample-output.md
│   └── sample-plan.json
└── screenshots/
    ├── workflow-full.png
    ├── notion-report.png
    └── slack-notification.png
```

---

## 🔧 Environment Variables
```env
ANTHROPIC_API_KEY=sk-ant-xxxxx
NOTION_API_KEY=secret_xxxxx
NOTION_DB_ID=your-research-reports-db-id
SLACK_WEBHOOK_URL=https://hooks.slack.com/services/xxx
MAX_QUESTIONS=8
```

---

## 🤝 Author
Built as part of AI Automation Engineer portfolio.

**Tech Stack:** n8n · Claude API · Web Search · Notion · Slack
